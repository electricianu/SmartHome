#pragma once
#include <Arduino.h>

class SmartHomeLib {
public:
    SmartHomeLib();
    void begin();
    void update();
};