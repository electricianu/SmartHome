#pragma once
#include <Arduino.h>

struct DeviceConfig {
    String deviceName = "SmartHomeDevice";
    bool debug = true;
};