#include "DeviceConfig.h"
// momentan gol — structura nu necesită implementare