#include "SmartHomeLib.h"

SmartHomeLib::SmartHomeLib() {}

void SmartHomeLib::begin() {
    // Inițializare module
}

void SmartHomeLib::update() {
    // Orchestrare loop
}